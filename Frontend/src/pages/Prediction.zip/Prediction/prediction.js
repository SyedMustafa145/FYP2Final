import React, { useState, useEffect } from "react";
import { Container, Row } from "reactstrap";
import ReactApexChart from "react-apexcharts";

//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb";

const Prediction = () => {
  const [breadcrumbItems, setBreadcrumbItems] = useState([
    { title: "Prediction Chart", link: "#" },
    { title: "Forex", link: "#" },
  ]);
  const [series, setSeries] = useState([
    {
      name: "candle",
      data: [],
    },
  ]);
  const [options, setOptions] = useState({
    chart: {
      height: 350,
      type: "candlestick",
    },
    title: {
      text: "CandleStick Chart - Category X-axis",
      align: "left",
    },
    annotations: {
      xaxis: [
        {
          x: "Oct 06 14:00",
          borderColor: "#00E396",
          label: {
            borderColor: "#00E396",
            style: {
              fontSize: "12px",
              color: "#fff",
              background: "#00E396",
            },
            orientation: "horizontal",
            offsetY: 7,
            text: "Annotation Test",
          },
        },
      ],
    },
    tooltip: {
      enabled: true,
    },
    xaxis: {
      type: "category",
      labels: {
        formatter: function (val) {
          let date = new Date(val);
          let options = { month: "short", day: "numeric", year: "numeric" };
          let formattedDate = date.toLocaleDateString("en-US", options);
          return formattedDate;
        },
      },
    },
    yaxis: {
      tooltip: {
        enabled: true,
      },
    },
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:5000/getChartData");
        const data = await response.json();
        let length = data.length;
        const updatedSeries = [
          {
            name: "candle",
            data: data.slice(length-200, length).map((item) => ({
              x: item.x,
              y: [item.y[0], item.y[1], item.y[2], item.y[3]],
            })),
          },
        ];
        setSeries(updatedSeries);
      } catch (error) {
        console.error(error);
      }
    };
    fetchData();
  }, []);

  return (
    <React.Fragment>
      <div className="page-content">
        <Container fluid>
          <Breadcrumbs
            title="Forex Prediction Chart"
            breadcrumbItems={breadcrumbItems}
          />
          <Row>
            <div id="chart">
              <ReactApexChart
                options={options}
                series={series}
                type="candlestick"
                height={550}
              />
            </div>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  );
};

export default Prediction;
